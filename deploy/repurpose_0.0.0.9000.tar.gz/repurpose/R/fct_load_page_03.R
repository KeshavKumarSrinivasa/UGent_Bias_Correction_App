#' load_page_03
#'
#' @description A fct function
#'
#' @return The return value, if any, from executing the function.
#'
#' @noRd
load_page_03 <- function(session) {
  htmlTemplate(app_sys("app/www/page3_outcomes.html"))
}
