#' load_page_04
#'
#' @description A fct function
#'
#' @return The return value, if any, from executing the function.
#'
#' @noRd
load_page_04 <- function() {
  htmlTemplate(app_sys("app/www/page4_parameters.html"))
}
