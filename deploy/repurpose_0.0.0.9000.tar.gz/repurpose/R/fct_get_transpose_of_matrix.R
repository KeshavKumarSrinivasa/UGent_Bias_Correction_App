#' get_transpose_of_matrix
#'
#' @description A fct function
#'
#' @return The return value, if any, from executing the function.
#'
#' @noRd
get_transpose_of_matrix <- function(metabolite_data_matrix) {
  t(metabolite_data_matrix)
}
